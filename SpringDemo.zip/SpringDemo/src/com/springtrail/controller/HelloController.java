package com.springtrail.controller;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class HelloController {
	@Resource(name="Userservice")
	private UserService Userservice;

//	@RequestMapping(method=RequestMethod.GET)
//	public ModelAndView welcome(){
//		return new ModelAndView("welcomePage", "welcomeMessage", "Welcome to Spring MVC World!!!");
//	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getPersons(Model model) {
		
		User calculatedBMI= 	Userservice.BMICalculator();	
		model.addAttribute("name", calculatedBMI.getName());
		model.addAttribute("BMI", calculatedBMI.BMI);
		return "welcomePage";
	}
}